import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './Components/login/login.component';
import { DashboardComponent } from './Components/dashboard/dashboard.component';
import { SabRegistrationComponent } from './Components/sab-registration/sab-registration.component';
import { SabStatusComponent } from './Components/sab-status/sab-status.component';
import { AddDetailsComponent } from './Components/add-details/add-details.component';
import { SearchComponent } from './Components/Customer/search/search.component';
import { PagenotfoundComponent } from './Components/pagenotfound/pagenotfound.component';
import { DefaultLayoutComponent } from './Components/default-layout/default-layout.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'
import { AuthGuardService } from './guard/auth.gaurd';
import { CustomerPipesComponent } from './Components/customer-pipes/customer-pipes.component';
import { AgePipe } from './pipes/age.pipe';
import { CreditcardmaskPipe } from './pipes/creditcardmask.pipe';
import { DecimalroundPipe } from './pipes/decimalround.pipe';
import { TelephonenumberPipe } from './pipes/telephonenumber.pipe';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    SabRegistrationComponent,
    SabStatusComponent,
    AddDetailsComponent,
    SearchComponent,
    PagenotfoundComponent,
    DefaultLayoutComponent,
    CustomerPipesComponent,
    AgePipe,
    CreditcardmaskPipe,
    DecimalroundPipe,
    TelephonenumberPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,

  ],
  providers: [AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
