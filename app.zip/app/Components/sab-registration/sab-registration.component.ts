import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { ExtraDetails } from 'src/app/model/covid-user';
import { CovidUserService } from 'src/app/service/covid-user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-sab-registration',
  templateUrl: './sab-registration.component.html',
  styleUrls: ['./sab-registration.component.css']
})
export class SabRegistrationComponent implements OnInit {
  mess:string='';
  authid:any;
  submit:boolean =false;
  registerForm:FormGroup = new FormGroup({
    firstName:new FormControl("",[Validators.required]),
    lastName:new FormControl("",[Validators.required]),
    email:new FormControl("",[Validators.required,Validators.email]),
    phoneNumber:new FormControl("",[Validators.required]),
    height:new FormControl("",[Validators.required]),
    weight:new FormControl("",[Validators.required]),
    gender:new FormControl("",[Validators.required]),
    birthDate:new FormControl("",[Validators.required]),
  });
  constructor(private fb:FormBuilder,private cs:CovidUserService) { }

  get f(){
    return this.registerForm.controls
  }
  ngOnInit(): void {
  }
  onSubmit(){
    this.submit = true;
    this.mess = '';
    
    this.authid = sessionStorage.getItem("Auth");
    if(this.registerForm.invalid)
    {
      if(this.f.firstName.errors && this.submit){this.mess = this.mess + "Enter The Valid FirstName \n"}
      if(this.f.lastName.errors && this.submit){this.mess =this.mess +  "Enter The Valid LastName \n"}
      if(this.f.email.errors && this.submit){this.mess = this.mess + "Enter The Valid Email \n"}
      if(this.f.phoneNumber.errors && this.submit){this.mess = this.mess + "Enter The Valid Phone Number \n"}
      if(this.f.weight.errors && this.submit){this.mess = this.mess + "Enter The Valid weight \n"}
      if(this.f.gender.errors && this.submit){this.mess = this.mess + "Enter The Valid Gender \n"}
      if(this.f.birthDate.errors && this.submit){this.mess = this.mess + "Enter The Valid BirthDate \n"}
      Swal.fire(this.mess, " ","error")
      return
    }
    if(this.registerForm.valid)
    {
      let u:ExtraDetails={
        "id":Math.random() * 1000000000,
        "userId":this.authid,
        "firstName":this.f.firstName.value,
        "lastName":this.f.lastName.value,
        "dob":this.f.birthDate.value,
        "phoneNumber":this.f.phoneNumber.value,
        "weight":this.f.weight.value,
        "height":this.f.height.value,
        "gender":this.f.gender.value,
        "status":"Complete"
      }
      this.cs.sabRegistration(u).subscribe((data)=>
      Swal.fire("Register Successfully","","success")
      );
    }
  }
}
