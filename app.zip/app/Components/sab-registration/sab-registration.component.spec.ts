import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SabRegistrationComponent } from './sab-registration.component';

describe('SabRegistrationComponent', () => {
  let component: SabRegistrationComponent;
  let fixture: ComponentFixture<SabRegistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SabRegistrationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SabRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
