import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SabStatusComponent } from './sab-status.component';

describe('SabStatusComponent', () => {
  let component: SabStatusComponent;
  let fixture: ComponentFixture<SabStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SabStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SabStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
