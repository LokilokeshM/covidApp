import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sab-status',
  templateUrl: './sab-status.component.html',
  styleUrls: ['./sab-status.component.css']
})
export class SabStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
