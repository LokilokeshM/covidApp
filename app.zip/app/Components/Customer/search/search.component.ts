import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  submitted = false;
  mess= "";
  mess1="";
  customer:Customer[]= [];
  searchForm:FormGroup=new FormGroup({
    name:new FormControl("",[Validators.required]),
    country:new FormControl("",[Validators.required]),
    city:new FormControl(""),
    email:new FormControl("")
  })
  constructor(private cust:CustomerService) { }


  get f() {return this.searchForm.controls}

  ngOnInit(): void {
  }
onSubmit()
{
  this.submitted= true;
  
  if(this.searchForm.invalid)
  {
    this.mess ='';
    if(this.submitted && this.f.name.errors){this.mess = "Enter The Name \n";}
    if(this.submitted && this.f.country.errors){this.mess = this.mess + "Choose Country Name";}
    Swal.fire(this.mess,"","error");
  }
  if(this.searchForm.valid)
  { 
    this.mess1 ='';
    let u = this.f.name.value;
    this.customer= [];
    this.cust.getCustomerSearch(u.toUpperCase( ),this.f.country.value).subscribe((res)=>{
      if(res.length == 0)
      {
        this.mess1="No Records Found"
      }
      else
      {
        this.customer = res;
      }
    })
  }
  
}
}
