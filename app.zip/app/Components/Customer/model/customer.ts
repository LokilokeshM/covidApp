export class Customer {
    CustomerName:string=""
    Country:string=""
    City:string=""
    Dob:string=""
    Age:number=0
    Phone:number=0
}
