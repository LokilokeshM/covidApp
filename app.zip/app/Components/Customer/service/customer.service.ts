import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../model/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  // custUrl:string ="http://localhost:3000/"
  // constructor(private http:HttpClient) { }

  // getCustomerSearch(a:string,b:string):Observable<Customer[]>
  // {
  //   alert(a + b);
  //   return this.http.get<Customer[]>(this.custUrl + "CustomerSearch?CustomerName="+ a +"&?Country=" +b );
  // }
}
