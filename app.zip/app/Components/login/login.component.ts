import { Component, OnInit } from '@angular/core';
  import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';
  import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { CovidUserService } from 'src/app/service/covid-user.service';
import { map } from 'rxjs/operators';
import { Auth, CovidRegistration, CovidUser } from 'src/app/model/covid-user';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  auth:Auth =new Auth(0);
    signupForm:FormGroup =new FormGroup({});
  loginForm:FormGroup = new FormGroup({});
  customer:CovidUser[]=[];
  constructor(private fb:FormBuilder,private cust:CovidUserService,private router:Router) { 
    this.loginFormValidation()
    this.signupFormValidator()
  }
  
  ngOnInit(): void {
  }
 
  loginFormValidation()
  {
    this.loginForm = this.fb.group({
      username:['',Validators.required],
      password:['',Validators.required]
    })
  }
  signupFormValidator()
  {
    this.signupForm = this.fb.group({
      username:['',Validators.required],
      password:['',Validators.required],
      repeatPassword:['',Validators.required],
      email:['',Validators.required]
    })
  }

  loginSubmit(user:string,pass:string)
  {
    if(this.loginForm.invalid)
    {
      alert("Enter The UserName and Password");
    }
    else{
      this.customer=[];
      // map(data=>data.filter(d=>d.userName == user))
      this.cust.loginService(user).pipe(map(data=>data.filter(d=>d.password == pass))).subscribe(
        (res)=>{
          if(res.length == 0 )
          {
            alert("Your Are not Register Please SignIN");
          }
          else{
            this.customer = res;
            console.log(this.customer);
            sessionStorage.setItem('user',JSON.stringify(this.customer));
            this.router.navigate(['dashboard']);
          }
        })
    }

  }

  registerSubmit(uName:string,pass:string,rePass:string,email:string)
  {
    if(this.signupForm.invalid)
    {
      Swal.fire("Enter The Values.....","","error")
      this.signupFormValidator()
    }
    else{
    if(pass == rePass)
    {
      let c:CovidRegistration;
      c ={
        "id":Math.random() /  100000,
        "userName":uName,
         "email":email,
          "password":pass,
          "status":"INCOMPLETE"
          }
    
          this.cust.registerService(c).subscribe((res)=>{
          this.auth = new Auth(c.id);
          sessionStorage.setItem('Auth',JSON.stringify(this.auth));
          this.router.navigate(['dashboard']);
      })
      }
    else
    {
       Swal.fire("Enter The Password And ReEnter Password Corred","",'error')
    }
    }
    
  }
}
