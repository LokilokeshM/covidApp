import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AddFamilyMembers, Auth, ExtraDetails } from 'src/app/model/covid-user';
import { CovidUserService } from 'src/app/service/covid-user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-details',
  templateUrl: './add-details.component.html',
  styleUrls: ['./add-details.component.css']
})
export class AddDetailsComponent implements OnInit {
  array:any = [];
   len:number=0;
  i = 0;

  mess:string='';
  authid:any;
  submit:boolean =false;
  registerForm:FormGroup = new FormGroup({
    
    firstName:new FormControl("",[Validators.required]),
    lastName:new FormControl("",[Validators.required]),
    email:new FormControl("",[Validators.required,Validators.email]),
    phoneNumber:new FormControl("",[Validators.required]),
    height:new FormControl("",[Validators.required]),
    weight:new FormControl("",[Validators.required]),
    gender:new FormControl("",[Validators.required]),
    birthDate:new FormControl("",[Validators.required]),
  });
  constructor(private fb:FormBuilder,private cs:CovidUserService) { 
   }
handleincrement(len:any)
{
  this.array = [];
  for (this.i = 0; this.i < len; this.i ++) {
    this.array.push(this.i); 
    this.registerForm= new FormGroup({
      firstName:new FormControl("",[Validators.required]),
      lastName:new FormControl("",[Validators.required]),
      email:new FormControl("",[Validators.required,Validators.email]),
      phoneNumber:new FormControl("",[Validators.required]),
      height:new FormControl("",[Validators.required]),
      weight:new FormControl("",[Validators.required]),
      gender:new FormControl("",[Validators.required]),
      birthDate:new FormControl("",[Validators.required]),
    });
  }
}
get f(){
    return this.registerForm.controls
}
ngOnInit(): void {
}
onSubmit(){
    this.authid = sessionStorage.getItem("Auth");
    this.submit = true;
    this.mess = '';
    if(this.registerForm.invalid)
    {
      if(this.f.firstName.errors && this.submit){this.mess = this.mess + "Enter The Valid FirstName \n"}
      if(this.f.lastName.errors && this.submit){this.mess =this.mess +  "Enter The Valid LastName \n"}
      if(this.f.email.errors && this.submit){this.mess = this.mess + "Enter The Valid Email \n"}
      if(this.f.phoneNumber.errors && this.submit){this.mess = this.mess + "Enter The Valid Phone Number \n"}
      if(this.f.weight.errors && this.submit){this.mess = this.mess + "Enter The Valid weight \n"}
      if(this.f.gender.errors && this.submit){this.mess = this.mess + "Enter The Valid Gender \n"}
      if(this.f.birthDate.errors && this.submit){this.mess = this.mess + "Enter The Valid BirthDate \n"}
      Swal.fire(this.mess, " ","error")
      return
    }
    if(this.registerForm.valid)
    {
      let u:AddFamilyMembers={
        "id":Math.random() * 1000000000,
        "userId":this.authid,
        "firstName":this.f.firstName.value,
        "lastName":this.f.lastName.value,
        "dob":this.f.birthDate.value,
        "phoneNumber":this.f.phoneNumber.value,
        "weight":this.f.weight.value,
        "height":this.f.height.value,
        "gender":this.f.gender.value,
      }
      this.cs.sabAddFamilyMembers(u).subscribe((data)=>
      Swal.fire("Register Successfully","","success")
      );
    }
  }

}
