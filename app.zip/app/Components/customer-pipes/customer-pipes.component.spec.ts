import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerPipesComponent } from './customer-pipes.component';

describe('CustomerPipesComponent', () => {
  let component: CustomerPipesComponent;
  let fixture: ComponentFixture<CustomerPipesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerPipesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerPipesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
