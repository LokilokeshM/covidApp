import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-pipes',
  templateUrl: './customer-pipes.component.html',
  styleUrls: ['./customer-pipes.component.css']
})
export class CustomerPipesComponent implements OnInit {
  birth:any;
  value:string="";
  value1:number=0;

  countryselect:String="";
num!:number;
h!:boolean;

  select(event:any)
  {
     this.countryselect=event.target.value;
  }

  
  constructor() { }

  ngOnInit(): void {
  }

}
