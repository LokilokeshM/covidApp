 
import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot,RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
 
 
@Injectable()
export class AuthGuardService implements CanActivate {
    constructor(private _router:Router ) {
    }
 
    canActivate(route: ActivatedRouteSnapshot,
                state: RouterStateSnapshot): boolean { 
                    console.log("Auth is working")
        // if (sessionStorage.getItem("Auth") == null)  {
        //     alert('You are not allowed to view this page');
        //     this._router.navigate(['']);
        //     return false;
        // } 
        return true;
    }
}


// class UserToken {}
// class Permissions {
//   canActivate(user: UserToken, id: string): boolean {
//     return true;
//   }
// }

// @Injectable()
// class CanActivateTeam implements CanActivate {
//   constructor(private permissions: Permissions, private currentUser: UserToken) {}

//   canActivate(
//     route: ActivatedRouteSnapshot,
//     state: RouterStateSnapshot
//   ): Observable<boolean|UrlTree>|Promise<boolean|UrlTree>|boolean|UrlTree {
//     return this.permissions.canActivate(this.currentUser, route.params.id);
//   }
// }