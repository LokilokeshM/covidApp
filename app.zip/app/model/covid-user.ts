export class CovidUser {
    userName:string='';
    password:string='';
    ts?:Date = new Date();
}
export class Auth
{ 
    constructor(id:any)
    {
        this.id= id;
    }
    id:number=0;
}
export class CovidRegistration {
    id:number=0;
    userName:string='';
    email:string='';
    password:string='';
    status:string='';
}
export class AddFamilyMembers {
    id:number=0;
    userId:string='';
    firstName:string='';
    lastName:string='';
    dob:string='';
    phoneNumber:number=0;
    weight:number=0;
    height:number=0;
    gender:string='';
}
export class ExtraDetails{
    id:number=0;
    userId:string='';
    firstName:string='';
    lastName:string='';
    dob:string='';
    phoneNumber:number=0;
    weight:number=0;
    height:number=0;
    gender:string='';
    status:string='';
}
