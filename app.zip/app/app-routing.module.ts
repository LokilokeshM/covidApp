import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddDetailsComponent } from './Components/add-details/add-details.component';
import { CustomerPipesComponent } from './Components/customer-pipes/customer-pipes.component';
import { SearchComponent } from './Components/Customer/search/search.component';
import { DashboardComponent } from './Components/dashboard/dashboard.component';
import { DefaultLayoutComponent } from './Components/default-layout/default-layout.component';
import { LoginComponent } from './Components/login/login.component';
import { PagenotfoundComponent } from './Components/pagenotfound/pagenotfound.component';
import { SabRegistrationComponent } from './Components/sab-registration/sab-registration.component';
import { SabStatusComponent } from './Components/sab-status/sab-status.component';
import { AuthGuardService } from './guard/auth.gaurd';
import { AddFamilyMembers } from './model/covid-user';

const routes: Routes = [{
  path:'',
  component:LoginComponent,
},
{
 path:'register',
 component:PagenotfoundComponent
},
{
path:'dashboard',
canActivate : [AuthGuardService] ,
component:DefaultLayoutComponent,
children:[{
  path:'',
  component:DashboardComponent
},
{
  path:'sabRegister',
  component:SabRegistrationComponent
},// {path:'sabStatus',loadChildren: () => import('./Components/sab-status/sab-status.component').then(m => m.)},
{
  path:'customerPipes',
  component:CustomerPipesComponent
},
{path:'addDetails',component:AddDetailsComponent
},
{path:'customerSearch',component:SearchComponent
}
]
},
{
path:'',
redirectTo:'/login',
pathMatch:'full'
},
{
  path:'**',
component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
