import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AddFamilyMembers, CovidRegistration, CovidUser, ExtraDetails } from '../model/covid-user';

@Injectable({
  providedIn: 'root'
})
export class CovidUserService {

  covidUrl:string ="http://localhost:3000/"
  constructor(private http:HttpClient) { }

  public loginService(a:string):Observable<CovidUser[]>
  {
    return this.http.get<CovidUser[]>(this.covidUrl +"customerLogin?userName="+a);
  }
  public registerService(a:CovidRegistration):Observable<CovidRegistration[]>
  {
    return this.http.post<CovidRegistration[]>(this.covidUrl+"CovidRegistration",a)
  }
  public sabRegistration(a:ExtraDetails):Observable<ExtraDetails[]>
  {
    return this.http.post<ExtraDetails[]>(this.covidUrl + "CovidRegistration",a)
  }
  public sabAddFamilyMembers(a:AddFamilyMembers):Observable<AddFamilyMembers[]>
  {
    return this.http.post<AddFamilyMembers[]>(this.covidUrl + "AddFamilyMembers",a)
  }
}
